﻿/// <reference path="jquery.validate.js" />  
/// <reference path="jquery.validate.unobtrusive.js" />
// Client Side Validation for CV_Leaflet custom data annotation
$.validator.addMethod(
    'cvleafletsent',
    function (value, element, params) {

        var semp1 = params.dateAck;
        var semp2 = params.leafSent;

        var w1 = $('#complaint_DATE_ACK').val();
        var w2 = $('#complaint_LEAFLET_SENT').prop('checked');

        if (w1 != '' && w2 == false)
            return false;
        else
            return true;
    });



$.validator.unobtrusive.adapters.add(
'cvleafletsent', ['dateack', 'leafsent'], function (options) {
    var params = {
        dateAck: options.params.dateack,
        leafSent: options.params.leafsent
    };
    options.rules['cvleafletsent'] = params;
    options.messages['cvleafletsent'] = options.message;
});



// Client Side Validation for DateCreateerThanComplaintDate custom data annotation
$.validator.addMethod(
    'dategreaterthancomplaintdate',
    function (value, element) {


        var datereceived = ProcessDate($('#complaint_DATE_RECEIVED').val());
        var datelogged = ProcessDate($('#complaint_DATE_LOGGED').val());
        var dateack = ProcessDate($('#complaint_DATE_ACK').val());
        var dateresponded = ProcessDate($('#complaint_DATE_RESPOND').val());

        if (datelogged < datereceived) {
            return false;
        }

        if (dateack != '') {
            if (dateack < datereceived) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }

        if (dateresponded != '') {
            if (dateresponded < datereceived) {
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }
    });

function ProcessDate(date) {
    if (date != '') {
        var parts = date.split('/');
        return new Date(parts[2], parts[1] - 1, parts[0]);
    }
    else {
        return '';
    }
}

$.validator.unobtrusive.adapters.addBool('dategreaterthancomplaintdate');
//'dategreaterthancomplaintdate', {}, function (options) {
    //var params = {
    //    dateAck: options.params.dateack,
    //    leafSent: options.params.leafsent
    //};
    //options.rules['dategreaterthancomplaintdate'] = {};
    //options.messages['dategreaterthancomplaintdate'] = options.message;
//});