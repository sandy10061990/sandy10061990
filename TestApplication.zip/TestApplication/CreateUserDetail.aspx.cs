﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TestApplication
{
    public partial class CreateUserDetail : System.Web.UI.Page
    {
        DataTable dt = new DataTable();
        bool bResult = true;
        bool Authenticate = true;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dt = GetTable();
                Session["GridRecord"] = dt;
            }
        }
        static DataTable GetTable()
        {
            // Step 2: here we create a DataTable.
            // ... We add 4 columns, each with a Type.
            DataTable table = new DataTable();
            DataColumn columnAutoID = new DataColumn("AutoID", typeof(int));
            columnAutoID.AutoIncrement = true;
            columnAutoID.AutoIncrementSeed = 1;
            table.Columns.Add(columnAutoID);
            table.Columns.Add("EMP_Number", typeof(string));
            table.Columns.Add("EMP_StaffNumber", typeof(string));
            table.Columns.Add("EMP_FirstName", typeof(string));
            table.Columns.Add("EMP_Middlename1", typeof(string));
            table.Columns.Add("EMP_Middlename2", typeof(string));
            table.Columns.Add("EMP_Lastname", typeof(string));
            table.Columns.Add("EMP_Address1", typeof(string));
            table.Columns.Add("EMP_Address2", typeof(string));
            table.Columns.Add("EMP_Address3", typeof(string));
            table.Columns.Add("EMP_Address4", typeof(string));
            table.Columns.Add("EMP_Address5", typeof(string));
            table.Columns.Add("EMP_EmailID", typeof(string));
            table.Columns.Add("BusinessMobile", typeof(string));
            table.Columns.Add("AccountIdentifier", typeof(string));

            //   table.Columns.Add("EMP_dob", typeof(DateTime));


            return table;
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {
            bool blnVal = true;
            int id = 0;
            id = Convert.ToInt32(Session["Emp_ID"]);
            validation(id);
            if (blnVal == true)
            {
                try
                {
                    if (id == 0)
                    {

                        dt = (DataTable)Session["GridRecord"];

                        if (dt.Rows.Count == 0)
                        {
                            dt = GetTable();
                        }


                        DataRow row = dt.NewRow();
                        row["EMP_Number"] = txtrefre.Text.Trim();
                        row["EMP_StaffNumber"] = txtStaffNumber.Text.Trim();
                        row["EMP_FirstName"] = txtFirstName.Text.Trim();
                        row["EMP_Middlename1"] = txtmiddlename1.Text.Trim();
                        row["EMP_Middlename2"] = txtmiddlename2.Text.Trim();
                        row["EMP_Lastname"] = txtlastName.Text.Trim();
                        row["EMP_Address1"] = txtAddress1.Text.Trim();
                        row["EMP_Address2"] = txtAddress2.Text.Trim();
                        row["EMP_Address3"] = txtAddress3.Text.Trim();
                        row["EMP_Address4"] = txtAddress4.Text.Trim();
                        row["EMP_Address5"] = txtAddress5.Text.Trim();
                        row["EMP_EmailID"] = txtEmailID.Text.Trim();
                        row["BusinessMobile"] = txtBusinessMobile.Text.Trim();
                        row["AccountIdentifier"] = ddlAccountIdentifier.SelectedValue.Trim();

                        dt.Rows.Add(row);

                        Session["GridRecord"] = dt;
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "myalert5", "alert('Inserted successfully.');", true);
                        UpdatePanel2.Update();
                        BindGrid();
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "myalert3", "openProcess(event, 'Process2');", true);
                        UpdatePanel1.Update();
                    }
                    else
                    {

                        DataTable dp = (DataTable)Session["GridRecord"];
                        DataRow[] rows = dp.Select("AutoID =" + id);
                        if (rows.Length > 0)
                        {
                            foreach (DataRow row in rows)
                            {

                                row["EMP_Number"] = txtrefre.Text.Trim();
                                row["EMP_StaffNumber"] = txtStaffNumber.Text.Trim();
                                row["EMP_FirstName"] = txtFirstName.Text.Trim();
                                row["EMP_Middlename1"] = txtmiddlename1.Text.Trim();
                                row["EMP_Middlename2"] = txtmiddlename2.Text.Trim();
                                row["EMP_Lastname"] = txtlastName.Text.Trim();
                                row["EMP_Address1"] = txtAddress1.Text.Trim();
                                row["EMP_Address2"] = txtAddress2.Text.Trim();
                                row["EMP_Address3"] = txtAddress3.Text.Trim();
                                row["EMP_Address4"] = txtAddress4.Text.Trim();
                                row["EMP_Address5"] = txtAddress5.Text.Trim();
                                row["EMP_EmailID"] = txtEmailID.Text.Trim();
                                row["BusinessMobile"] = txtBusinessMobile.Text.Trim();
                                row["AccountIdentifier"] = ddlAccountIdentifier.SelectedValue.Trim();
                                dp.AcceptChanges();
                                row.SetModified();
                            }
                        }
                        Session["GridRecord"] = dp;
                        BindGrid();
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "myalert3", "openProcess(event, 'Process2');", true);
                        UpdatePanel1.Update();
                    }


                }
                catch (Exception ex)
                {

                    ex.ToString();
                }

            }
        }
        private void BindGrid()
        {
            DataTable dp = (DataTable)Session["GridRecord"];


            GridView1.DataSource = dp;
            //  GridView1.DataValueField = "ID";
            GridView1.DataBind();
        }

        public bool validation(int id)
        {
            string strMsessage = String.Empty;
            bResult = true;
            if (txtrefre.Text.Trim() != "")
            {
                if (txtrefre.Text.ToString().StartsWith("E") || txtrefre.Text.ToString().StartsWith("C"))
                {
                    if (txtrefre.Text.ToString().Length > 9)
                    {
                        if (txtrefre.Text.ToString().Contains("A"))
                        {
                            if (txtrefre.Text.ToString().Length.ToString() == "11")
                            {

                            }
                            else
                            {
                                if (Convert.ToInt32(txtrefre.Text.ToString().Length.ToString()) > 11)
                                {
                                    strMsessage = strMsessage + "<br/>" + "Unique Reference Number is greater than 11 digit";
                                }
                                else
                                {
                                    strMsessage = strMsessage + "<br/>" + "Unique Reference Number is less than 11 digit";
                                }
                                bResult = false;
                            }
                        }
                    }
                    else
                    {
                        if (txtrefre.Text.ToString().Length.ToString() == "9")
                        {

                        }
                        else
                        {
                            if (Convert.ToInt32(txtrefre.Text.ToString().Length.ToString()) > 9)
                            {
                                strMsessage = strMsessage + "<br/>" + "Unique Reference Number is greater than 9 digit";
                            }
                            else
                            {
                                strMsessage = strMsessage + "<br/>" + "Unique Reference Number is less than 9 digit";
                            }
                            bResult = false;
                        }
                    }

                }
                else
                {
                    strMsessage = strMsessage + "<br/>" + "Please check Unique Reference Number, It should start with E or C";
                    bResult = false;
                }
            }
            else
            {
                strMsessage = strMsessage + "<br/>" + "Enter Unique Reference Number";
                bResult = false;

            }





            if (ddlAccountIdentifier.SelectedValue == "0")
            {
                strMsessage = strMsessage + "<br/>" + "Please select Account Identifier";
                bResult = false;
            }


            if (id != 0)
            {
                if (txtEmailID.Text.ToString() == "")
                {
                    strMsessage = strMsessage + "<br/>" + "Please enter Email-ID";
                    bResult = false;
                }
            }




            if (txtFirstName.Text.ToString().Trim() == "")
            {
                strMsessage = strMsessage + "<br/>" + "Please enter first name";
                bResult = false;
            }
            if (txtlastName.Text.ToString().Trim() == "")
            {
                strMsessage = strMsessage + "<br/>" + "Please enter last name";
                bResult = false;
            }
            if (txtAddress1.Text.ToString().Trim() == "")
            {
                strMsessage = strMsessage + "<br/>" + "Please enter Address 1";
                bResult = false;
            }
            if (txtAddress2.Text.ToString().Trim() == "")
            {
                strMsessage = strMsessage + "<br/>" + "Please enter Address 2";
                bResult = false;
            }
            if (txtAddress3.Text.ToString().Trim() == "")
            {
                strMsessage = strMsessage + "<br/>" + "Please enter Address 3";
                bResult = false;
            }
            if (txtAddress4.Text.ToString().Trim() == "")
            {
                strMsessage = strMsessage + "<br/>" + "Please enter Address 4";
                bResult = false;
            }
            if (txtAddress5.Text.ToString().Trim() == "")
            {
                strMsessage = strMsessage + "<br/>" + "Please enter Address 5";
                bResult = false;
            }




            if (strMsessage != "")
            {
                lblErrorMassage.Text = strMsessage.ToString();
                lblErrorMassage.Visible = true;
            }
            return bResult;
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Session["Emp_ID"] = 0;
            if (e.CommandName == "Edit1")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                Session["Emp_ID"] = index;

                DataTable dp = (DataTable)Session["GridRecord"];
                if (dp.Rows.Count > 0)
                {
                    foreach (DataRow row in dp.Rows)
                    {
                        if (index == Convert.ToInt32(row["AutoID"].ToString()))
                        {
                            txtrefre.Text = row["EMP_Number"].ToString();
                            txtStaffNumber.Text = row["EMP_StaffNumber"].ToString();
                            txtFirstName.Text = row["EMP_FirstName"].ToString();
                            txtmiddlename1.Text = row["EMP_Middlename1"].ToString();
                            txtmiddlename2.Text = row["EMP_Middlename2"].ToString();
                            txtlastName.Text = row["EMP_Lastname"].ToString();
                            txtAddress1.Text = row["EMP_Address1"].ToString();
                            txtAddress2.Text = row["EMP_Address2"].ToString();
                            txtAddress3.Text = row["EMP_Address3"].ToString();
                            txtAddress4.Text = row["EMP_Address4"].ToString();
                            txtAddress5.Text = row["EMP_Address5"].ToString();
                            txtEmailID.Text = row["EMP_EmailID"].ToString();
                            txtBusinessMobile.Text = row["BusinessMobile"].ToString();
                            ddlAccountIdentifier.SelectedValue = row["AccountIdentifier"].ToString();
                        }
                    }
                }
                ScriptManager.RegisterStartupScript(this, this.GetType(), "myalert3", "openProcess(event, 'Process1');", true);
                UpdatePanel2.Update();
                UpdatePanel1.Update();

            }
            if (e.CommandName == "Delete1")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                DataTable dp = (DataTable)Session["GridRecord"];
                DataRow[] row1 = dp.Select("AutoId =" + index);
                foreach (var rows in row1)
                {
                    rows.Delete();
                }
                Session["GridRecord"] = dp;
                BindGrid();
                UpdatePanel1.Update();
            }

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            clear();

        }
        public void clear()
        {
            txtrefre.Text = string.Empty;
            txtStaffNumber.Text = string.Empty;
            txtFirstName.Text = string.Empty;
            txtmiddlename1.Text = string.Empty;
            txtmiddlename2.Text = string.Empty;
            txtlastName.Text = string.Empty;
            txtAddress1.Text = string.Empty;
            txtAddress2.Text = string.Empty;
            txtAddress3.Text = string.Empty;
            txtAddress4.Text = string.Empty;
            txtAddress5.Text = string.Empty;
            txtEmailID.Text = string.Empty;
            txtBusinessMobile.Text = string.Empty;
            ddlAccountIdentifier.ClearSelection();
        }

    }

}